Total lines in addr trace
--------------------------
prog2--The total address count is  2531784
prog4-- The total address count is  1064762

